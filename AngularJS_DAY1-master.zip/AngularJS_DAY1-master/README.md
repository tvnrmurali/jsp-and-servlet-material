# AngularJS_DAY1
Till 2 way binding
